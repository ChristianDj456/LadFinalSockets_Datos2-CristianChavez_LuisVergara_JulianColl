package client_lab;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Client_Threads extends Thread {

    private DataInputStream in;
    private DataOutputStream out;

    public Client_Threads(DataInputStream in, DataOutputStream out) {
        this.in = in;
        this.out = out;
    }
    Scanner ram = new Scanner(System.in);

    public void run() {

        String msg;
        int op = 0;
        boolean exit = false;

        while (!exit) {

            try {
                System.out.println("1.MergeSort");
                System.out.println("2.HeapSort");
                System.out.println("3.QuickSort");
                System.out.println("4.Exit");

                op = ram.nextInt();

                out.writeInt(op);

                switch (op) {
                    case 1:
                        System.out.println("Algoritmo de MergeSort");
                        System.out.println("Digite el tamaño del arreglo");
                        int n = ram.nextInt();
                        out.writeInt(n);
                        int[] array = new int[n];
                        for (int i = 0; i < n; i++) {
                            System.out.println("Digite el dato en la posicion " + i);
                            array[i] = ram.nextInt();
                            out.writeInt(array[i]);
                        }

                        String msgMerge = in.readUTF();     //Leyendo
                        System.out.println(msgMerge); //Mensaje del Servidor
                        int start = 0;
                        int end = array.length - 1;

                        out.writeInt(start);
                        out.writeInt(end);

                        System.out.println("Ordenamiento Merge Sort");
                        for (int i = 0; i < array.length; i++) {
                            array[i] = in.readInt();
                            System.out.println(array[i]);
                            String mensajeM = in.readUTF();
                            System.out.println(mensajeM);
                        }

                        String msgMerge2 = in.readUTF();
                        System.out.println(msgMerge2);

                        double tiempo = in.readDouble();
                        System.out.println("El Tiempo de ejecucion del Algoritmo de MergeSort fue " + tiempo);
                        break;
                    case 2:
                        System.out.println("Algoritmo de Heap Sort");
                        int nh;
                        System.out.println("Digite el tamaño");
                        nh = ram.nextInt();
                        out.writeInt(nh);
                        int[] arr = new int[nh];

                        for (int k = 0; k < nh; k++) {
                            System.out.println("Digite en la pos " + k);
                            arr[k] = ram.nextInt();
                            out.writeInt(arr[k]);
                        }

                        String msgHeap = in.readUTF();
                        System.out.println(msgHeap);

                        System.out.println("Ordenamiento HeapSort");
                        for (int k = 0; k < arr.length; k++) {
                            arr[k] = in.readInt();
                            System.out.println(" " + arr[k]);
                            String mensajeH = in.readUTF();
                            System.out.println(mensajeH);
                        }

                        String msgHeap2 = in.readUTF();
                        System.out.println(msgHeap2);

                        double time = in.readDouble();
                        System.out.println("El tiempo de ejecucion del Algoritmo de HeapSort fue " + time);

                        break;

                    case 3:
                        int nq;
                        System.out.println("Digite el tamaño");
                        nq = ram.nextInt();
                        out.writeInt(nq);
                        int ar[] = new int[nq];

                        for (int l = 0; l < nq; l++) {
                            System.out.println("Digite en la pos " + l);
                            ar[l] = ram.nextInt();
                            out.writeInt(ar[l]);
                        }

                        System.out.println("Digite el pivote");
                        System.out.println("1.Izquierdo");
                        System.out.println("2.Derecho");

                        int pivote = ram.nextInt();
                        out.writeInt(pivote);

                        if (pivote == 1) {
                            System.out.println("Ordenamiento QuickSort Izquierdo");
                            String msgQuick = in.readUTF();
                            System.out.println(msgQuick);
                            for (int l = 0; l < ar.length; l++) {
                                ar[l] = in.readInt();
                                System.out.println(" " + ar[l]);
                                String mensaje = in.readUTF();
                                System.out.println(mensaje);
                            }
                            String msgQuick2 = in.readUTF();
                            System.out.println(msgQuick2);
                            double tiempoQuick = in.readDouble();
                            System.out.println("El tiempo de ejecucion del algoritmo de QuickSort fue " + tiempoQuick);
                        } else {
                            if (pivote == 2) {
                                System.out.println("Ordenamiento QuickSort Derecho");

                                String msgQuick = in.readUTF();
                                System.out.println(msgQuick);
                                for (int l = 0; l < ar.length; l++) {
                                    ar[l] = in.readInt();
                                    System.out.println(" " + ar[l]);
                                    String mensaje = in.readUTF();
                                    System.out.println(mensaje);
                                }

                                String msgQuick2 = in.readUTF();
                                System.out.println(msgQuick2);
                                double tiempoQuick = in.readDouble();
                                System.out.println("El tiempo de ejecucion del algoritmo de QuickSort fue " + tiempoQuick);
                            }
                        }

                        break;
                    case 4:
                        ram.close();
                        break;

                }
            } catch (IOException ex) {
                Logger.getLogger(Client_Threads.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }
}
