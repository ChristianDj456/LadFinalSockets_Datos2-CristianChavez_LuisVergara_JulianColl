package client_lab;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Client_Lab {

    
public static void main(String[] args) {
 try {
            Scanner rem = new Scanner(System.in);
            rem.useDelimiter("\n");
            
           // Socket sc = new Socket("192.168.212.1", 7777); // Externo
            Socket sc = new Socket("127.0.0.1", 7777); //Local
            
            DataInputStream in = new DataInputStream(sc.getInputStream());
            DataOutputStream out = new DataOutputStream(sc.getOutputStream());
            
            String msg = in.readUTF();
            System.out.println(msg);
            
            //String vector="1_2,4,45,5,6";
            String name = rem.next();
            out.writeUTF(name);
            
            Client_Threads thread = new Client_Threads(in, out);
            thread.start();
            thread.join();
            
        } catch (IOException ex) {
            Logger.getLogger(Client_Lab.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InterruptedException ex) {
            Logger.getLogger(Client_Lab.class.getName()).log(Level.SEVERE, null, ex);
        }    
}
    
}
