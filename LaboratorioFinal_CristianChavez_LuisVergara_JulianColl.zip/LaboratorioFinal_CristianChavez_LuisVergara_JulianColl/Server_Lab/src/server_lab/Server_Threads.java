/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server_lab;

import Ordenamientos.HeapSort;
import Ordenamientos.OrdenamientoQuick;
import Ordenamientos.QuickSortGeek;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author CRISTIAN DE JESUS
 */
public class Server_Threads extends Thread {

    private DataInputStream in;
    private DataOutputStream out;
    private String Ordena;

    public Server_Threads(DataInputStream in, DataOutputStream out, String Ordena) {
        this.in = in;
        this.out = out;
        this.Ordena = Ordena;
    }

    public void run() {

        String msg;
        int op;

        while (true) {

            try {
                op = in.readInt();

                switch (op) {
                    case 1:
                        int n = in.readInt();
                        int[] array = new int[n];
                        String mensajeM = "...";

                        for (int i = 0; i < n; i++) {
                            array[i] = in.readInt();
                            // System.out.println(" "+array[i]);
                        }

                        String msgMerge = "Iniciando el ordenamiento de Merge Sort.....";
                        out.writeUTF(msgMerge); //Mensaje al cliente
                        int start = in.readInt();
                        int end = in.readInt();

                        long inicio = System.currentTimeMillis();

                        array = MergeSort(array, start, end);

                        long fin = System.currentTimeMillis();

                        double tiempo = (double) ((fin + inicio) + 1);

                        for (int i = 0; i < array.length; i++) {
                            // System.out.println(array[i]);
                            out.writeInt(array[i]);
                            out.writeUTF(mensajeM);
                        }
                        String msgMerge2 = "Finalizo el ordenamiento de MergeSort";
                        out.writeUTF(msgMerge2);
                        out.writeDouble(tiempo);

                        break;
                    case 2:
                        int nh = in.readInt();
                        int[] arr = new int[nh];
                        String mensajeH = "...";

                        for (int k = 0; k < nh; k++) {
                            arr[k] = in.readInt();
                            System.out.println(arr[k]);
                        }

                        String msgHeap = "Iniciando el ordenamiento de Heap Sort.....";
                        out.writeUTF(msgHeap); //Mensaje al cliente
                        // sort(arr);
                        long iniciar = System.currentTimeMillis();

                        HeapSort ob = new HeapSort();
                        ob.sort(arr);

                        long fini = System.currentTimeMillis();

                        double time = (double) ((fini + iniciar));

                        for (int k = 0; k < arr.length; k++) {

                            out.writeInt(arr[k]);
                            out.writeUTF(mensajeH);
                        }
                        String msgHeap2 = "Finalizo el ordenamiento de Heap Sort";
                        out.writeUTF(msgHeap2);
                        out.writeDouble(time);

                        break;
                    case 3:
                        int nq = in.readInt();
                        int ar[] = new int[nq];
                        String mensaje = "...";

                        for (int l = 0; l < nq; l++) {
                            ar[l] = in.readInt();
                            // System.out.println(ar[l]); // Mostrando Vector en el Server
                        }

                        int pivote = in.readInt();
                        if (pivote == 1) {

                            String msgQuick = "Iniciando el ordenamiento de Quick Sort.....";
                            out.writeUTF(msgQuick); //Mensaje al cliente

                            long inicioQuick = System.currentTimeMillis();

                            OrdenamientoQuick object = new OrdenamientoQuick();
                            object.QuicksortLeft(ar);

                            long finQuick = System.currentTimeMillis();

                            for (int l = 0; l < ar.length; l++) {
                                out.writeInt(ar[l]);

                                out.writeUTF(mensaje);
                            }

                            double tiempoQuick = (double) ((finQuick + inicioQuick) -1);
                            String msgQuick2 = "Finalizo el ordenamiento de Quick Sort";
                            out.writeUTF(msgQuick2);
                            out.writeDouble(tiempoQuick);

                        } else {
                            if (pivote == 2) {

                                String msgQuick = "Iniciando el ordenamiento de Quick Sort.....";
                                out.writeUTF(msgQuick); //Mensaje al cliente

                                long inicioQuick = System.currentTimeMillis();

                                QuickSortGeek objeto = new QuickSortGeek();
                                objeto.QuickSort(ar, 0, nq - 1);

                                long finQuick = System.currentTimeMillis();

                                for (int l = 0; l < ar.length; l++) {
                                    out.writeInt(ar[l]);
                                    out.writeUTF(mensaje);
                                }

                                double tiempoQuick = (double) ((finQuick + inicioQuick)-1);
                                String msgQuick2 = "Finalizo el ordenamiento de Quick Sort";
                                out.writeUTF(msgQuick2);
                                out.writeDouble(tiempoQuick);
                            }
                        }

                        break;
                    default:

                }
            } catch (IOException ex) {
                Logger.getLogger(Server_Threads.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public int[] MergeSort(int a[], int S, int E) {
        int bet;
        if (S < E) {
            bet = (S + E) / 2;
            MergeSort(a, S, bet);
            MergeSort(a, bet + 1, E);
            Mezclar(a, S, bet, E);
        }

        return a;
    }

    public void Mezclar(int a[], int left, int between, int right) {
        int temp[] = new int[a.length];
        int x, y, z;
        x = z = left;

        y = between + 1;
        while (x <= between && y <= right) {
            if (a[x] <= a[y]) {
                temp[z++] = a[x++];
            } else {
                temp[z++] = a[y++];
            }
        }//Fin While

        while (x <= between) {
            temp[z++] = a[x++];
        }//Fin While

        while (y <= right) {
            temp[z++] = a[y++];
        }//Fin While

        System.arraycopy(temp, left, a, left, right - left + 1);
    }

    // Heap
    public void sort(int arr[]) {
        int n = arr.length;

        // Build heap (rearrange array)
        for (int i = n / 2 - 1; i >= 0; i--) {
            heapify(arr, n, i);
        }

        // One by one extract an element from heap
        for (int i = n - 1; i > 0; i--) {
            // Move current root to end
            int temp = arr[0];
            arr[0] = arr[i];
            arr[i] = temp;

            // call max heapify on the reduced heap
            heapify(arr, i, 0);
        }
    }

    public void heapify(int arr[], int n, int i) {
        int largest = i; // Initialize largest as root
        int l = 2 * i + 1; // left = 2*i + 1
        int r = 2 * i + 2; // right = 2*i + 2

        // If left child is larger than root
        if (l < n && arr[l] > arr[largest]) {
            largest = l;
        }

        // If right child is larger than largest so far
        if (r < n && arr[r] > arr[largest]) {
            largest = r;
        }

        // If largest is not root
        if (largest != i) {
            int swap = arr[i];
            arr[i] = arr[largest];
            arr[largest] = swap;

            // Recursively heapify the affected sub-tree
            heapify(arr, n, largest);
        }
    }

    public static void printArray(int arr[]) {
        int n = arr.length;
        for (int i = 0; i < n; ++i) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }
}
