package server_lab;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Server_Lab {

    public static void main(String[] args) {
        try {
            ServerSocket server = new ServerSocket(7777);
            //InetAddress address=InetAddress.getLocalHost();
           // InetAddress address = InetAddress.getByName ("192.43.16.1");
            Socket sc;

            System.out.println("Server Started");
            while (true) {

                sc = server.accept();

                DataInputStream in = new DataInputStream(sc.getInputStream());
                DataOutputStream out = new DataOutputStream(sc.getOutputStream());

                out.writeUTF("Indica tu nombre");
                String NameClient = in.readUTF();

                Server_Threads thread = new Server_Threads(in, out, NameClient);
                thread.start();
                //ordenamientos(NameClient);
                System.out.println("Creada la conexion con el cliente " + NameClient);

            }
        } catch (IOException ex) {
            Logger.getLogger(Server_Lab.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static String ordenamientos(String mensaje) {

        String[] partes = mensaje.split("_");
        int tipo = Integer.parseInt(partes[0]);
        String vector = partes[1];

        String[] numeros = vector.split(",");

        int[] vec = new int[numeros.length];
        for (int i = 0; i < numeros.length; i++) {
            vec[i] = Integer.parseInt(numeros[i]);
        }

        switch (tipo) {
            case 1:
                       
                break;
            case 2:
                break;
            case 3:
                break;
            default:
        }

        for (int i = 0; i < numeros.length; i++) {
            System.out.println(vec[i]);
        }

        return vector;
    }
    
}
