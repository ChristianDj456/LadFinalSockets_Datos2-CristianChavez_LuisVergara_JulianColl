
package Ordenamientos;


public class OrdenamientoQuick {
  
    public void QuicksortLeft(int[] array) {
        array = QuicksortL(array);
    }

    public int[] QuicksortL(int num[]) {
        return QuickSortLeft(num, 0, num.length - 1);
    }
    
    public int[] QuickSortLeft(int nums[], int left, int right) {
        if (left >= right) {
            return nums;
        }
        int i = left, d = right;
        if (left != right) {
            int pivote;
            int aux;
            pivote = left;
            while (left != right) {
                while (nums[right] >= nums[pivote] && left < right) {
                    right--;
                }
                while (nums[left] < nums[pivote] && left < right) {
                    left++;
                }
                if (right != left) {
                    aux = nums[right];
                    nums[right] = nums[left];
                    nums[left] = aux;
                }
            }
            if (left==right) {
                QuickSortLeft(nums,i,left-1);
                QuickSortLeft(nums,left+1,d);
            }
        }else{
            return nums;
        }
        return nums;
    }
}
